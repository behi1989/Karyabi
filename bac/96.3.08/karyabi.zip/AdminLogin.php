<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin Login</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/admin.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <!-- Login Panel -->
      <div class="container">

      <form class="form-signin">
      <div class="panel panel-primary">
      	<div class="panel-heading">
        	<h4 class="form-signin-heading">ورود به پنل</h4>
        </div>
        <div class="panel-body">
            <label for="inputUsername" class="sr-only">نام کاربری</label>
            <input type="text" id="inputEmail" class="form-control" placeholder="نام کاربری خود را وارد کنید..." required autofocus>
            <label for="inputPassword" class="sr-only">کلمه عبور</label>
            <input type="password" id="inputPassword" class="form-control" placeholder="کلمه عبور خود را وارد کنید..." required>
            <div class="checkbox">
              <label>
                <input type="checkbox" value="remember-me" class="check-box"><label class="check-txt">مرا به خاطر بسپار</label>
              </label>
            </div>
            <button class="btn btn-lg btn-primary btn-block" type="submit">ورود</button>
        </div>
      </div>
      </form>

    </div> <!-- /container -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>