<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>موسسه کاریابی نیاز رشت</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/main-css.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css"> 
    <link href="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-8/16/Addons-icon.png" rel="shortcut icon">
    
  </head>
  
  <body>
  
  <!--Search -->
  <div id="search-modal" class="modal fadeInLeftBig">
  <div class="modal-dialog" style="margin: 0; left: 100px; top: 24px">
  	<div class="modal-content" style="width: 250px;background: none;border: 0;box-shadow: none">
  		<div class="searchbar">
  		<div class="modal-body" style="direction: ltr;padding: 3px">
  			<div class="input-group">
				<div class="input-group-btn">
					<button class="btn" id="btn-submit" type="submit"><i class="fa fa-search"></i></button>
				</div>
				<input class="form-control" id="txt-search" type="text" style="direction: rtl"  placeholder="متن خود را وارد نمایید...">
			</div>
		</div>
  		</div>
  	</div>
  </div>	
  </div>
  
  	<!-- Login form -->
 	 <div id="myModal" class="modal fade"  role="dialog">
     	<div class="modal-dialog" style="max-width: 450px">
        
     		<div class="modal-content">
            
                <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 style="color: #F04903">ورود به سایت</h4>
                </div>
                
                <div class="modal-body">
                    <form action="login.php" method="post" role="form">
                        <div class="form-group">
                            <label for="usrname">نام کاربری</label>
                            <input type="text" class="form-control" id="usrname" placeholder="نام کاربری را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="psw">کلمه عبور</label>
                            <input type="text" class="form-control" id="psw" placeholder="کلمه عبور را وارد نمایید">
                        </div>
                        <div class="checkbox">
                            <input type="checkbox" value="" checked><label>مرا به خاطر بسپار</label>
                        </div>
                        <button type="submit" class="btn btn-success btn-block">ورود</button>
                    </form>
                </div>
        
                <div class="modal-footer">
                    <p><a href="#">فراموشی کلمه عبور؟</a></p>
                    <p> آیا عضو نیستید؟ <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#RegModal" data-dismiss="modal">ثبت نام</button>
                    <button type="submit" class="btn btn-danger" data-dismiss="modal">انصراف</button></p>
                </div>
                
      		</div>
            
		</div>
	</div>
   
   <!-- Register form -->
   <div id="RegModal" class="modal fade"  role="dialog">
     	<div class="modal-dialog" style="max-width: 400px">
        
     		<div class="modal-content">
            
                <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 style="color: #F04903">ثبت نام در سایت</h4>
                </div>
                
                <div class="modal-body">
                    <form action="register.php" method="post" role="form">
                        <div class="form-group">
                            <label for="name">نام</label>
                            <input type="text" class="form-control" id="mo-fname" placeholder="نام خود را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="family">نام خانوادگی</label>
                            <input type="text" class="form-control" id="mo-lname" placeholder="نام خانوادگی را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="username">نام کاربری</label>
                            <input type="text" class="form-control" id="mo-uname" placeholder="نام کاربری را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="email">پست الکترونیکی</label>
                            <input type="text" class="form-control" id="mo-email" placeholder="پست الکترونیکی را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="psw">کلمه عبور</label>
                            <input type="text" class="form-control" id="mo-psw" placeholder="کلمه عبور را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="re-psw">تایید کلمه عبور</label>
                            <input type="text" class="form-control" id="mo-repsw" placeholder="کلمه عبور را دوباره وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="captcha">کد امنیتی</label>
                            
                        </div>
                    </form>
                </div>
        
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-dismiss="modal">ثبت نام</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal" data-toggle="modal" data-target="#myModal">ورود</button>
                </div>
                
      		</div>
            
		</div>
	</div>
    
    <!--header-->
    <header id="header">
    	<div class="container-fluid text-center">
            <div class="logo">
                <a href="index.php"><h2 class="logo-txt wow fadeInRight">نیاز رشت</h2></a>
                <a href="index.php"><h6 class="logo-txt wow fadeInRight">تبلیغات/استخدام و کاریابی</h6></a>
            </div>
            <div class="login text-center">
            	<a href="#"><i class="login-tx fa fa-user-o fa-2x wow fadeIn" data-toggle="modal" data-target="#myModal"></i></a>
                <a href="#"><i class="search-tx fa fa-search fa-2x wow fadeIn" data-toggle="modal" data-target="#search-modal"></i></a>
            </div>
        </div>
        	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-toggles">
            	<span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
    </header>
    
    <!--navbar-->
    <nav id="navbar">
    
    	<div class="container-fluid text-center">
        	
            <div class="nav-toggles navbar-collapse collapse">
        	<ul class="nav nav-pills">
            	<li style="margin-top:5px;padding-top:2px"><a href="about.php">درباره ما</a></li> 
                <li id="contac-us" style="margin-top:5px;padding-top:2px"><a href="contactus.php">تماس با ما</a></li> 
                <li style="margin-top:5px;padding-top:2px"><a href="#">شرکت ها</a></li>
                <li style="margin-top:5px;padding-top:2px"><a href="#">مشاغل گیلان</a></li>
                <li style="margin-top:5px;padding-top:2px"><a href="#">فرصت شغلی</a></li> 
                <li style="margin-top:5px;padding-top:2px"><a href="#">تبلیغات</a></li>
            	<li><a href="index.php"><i class="fa fa-home fa-2x"></i></a></li>         	
            </ul>
            </div>
        </div>
    </nav>
   
    <!-- About us -->
    <section id="about-us">
    	<div class="container-fluid text-center">
    		<div class="row">
    			<div class="col-xs-12">
					<div class="about-text">
						<span><br></span>
						<span><br></span>
						<span><h4 style="padding-right: 30px">موسسه تبلیغات و کاریابی نیاز رشت</h4></span>
						<span><br></span>
						<span><h5 style="padding: 0 30px;line-height: 30px">وب سایت نیاز رشت در فروردین سال 1396 فعالیت رسمی خود را آغاز نموده و در راستای تبلیغ برای مراکز، سازمان ها و شرکت های دولتی و خصوصی و همچنین محیطی برای کارجویان و دانشجویان فارغ التحصیل صرفا جهت سهولت در دست یابی سریع و بروز فرصت های شغلی پا به عرصه گذاشته است. </h5></span>
						<span><br></span>
						<span><h5 style="padding: 0 30px"><i class="fa fa-map-marker fa-2x" ></i>&nbsp; گیلان - رشت</h5></span>
						<span><h5 style="padding: 0 30px"><i class="fa fa-envelope fa-2x" ></i>&nbsp; ایمیل : Info[@]niazerasht.ir</h5></span>
						<span><h5 style="padding: 0 30px"><i class="fa fa-fax fa-2x" ></i>&nbsp; شماره تماس : 2323 - 013</h5></span>
					</div>
    			</div>
    		</div>
    	</div>
    </section> 
   
  	<!-- footer -->
	<footer id="footer">
    	<div class="container text-center">
        	<div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <a href="index.php"><h2 class="logo-txt">نیاز رشت</h2></a>
                        <a href="index.php"><h6 class="logo-txt">تبلیغات/استخدام و کاریابی</h6></a>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <h4 class="footer-text">در شبکه های اجتماعی دنبال کنید</h4>
                        <div class="footer-img">
                        	<ul>
                            	<li class="facebook"><a href="https://www.facebook.com/niazerasht"><i class="fa fa-facebook-square"></i></a></li>
                                <li class="twitter"><a href="https://twitter.com/niazerasht"><i class="fa fa-twitter-square"></i></a></li>
                                <li class="instagram"><a href="http://instagram.com/niazerasht"><i class="fa fa-instagram"></i></a></li>
                                <li class="linkedin"><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                                <li class="telegram"><a href="http://telegram.me/niazerasht"><i class="fa fa-telegram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo text-center">
                        <h4 class="footer-text">عضویت در خبرنامه</h4>
                        <div class="input-group">
                            <div class="input-group-btn">
                            	<button class="btn" id="btn-submits" type="submit">ارسال</button>
                            </div>
                            <input class="form-control" id="txt-email" type="text" placeholder="ایمیل خود را وارد کنید...">
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logos">
                        <h5 class="footer-text">مختصری از نیاز رشت</h5>
                        <p class="mini-about text-justify">
                        	وب سایت نیاز رشت در سال 1396 تاسیس شده است. فعالیت های این وب سایت بیشتر در حوزه کاریابی و تبلیغات بصورت درون شهری، فضای مجازی و ... می باشد. 
                        </p>
                    </div>
                </div>

            </div>
            
        </div>
        <span class="go-top">
            <a href="#top"><i class="fa fa-chevron-circle-up"></i></a>
        </span>
        <span class="text-center">
        <h6 class="footer-copyright"><i class="fa fa-copyright"></i> Copyright 2017 &nbsp; طراحی توسعه و پشتیبانی توسط تیم طراحی و توسعه رش بیت</h6>
        </span>
    </footer>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    
    <!-- wow animation -->
    <script>
		new WOW().init();
	</script>
    
  	<!-- Go top -->
	<script>
    	$(document).ready(function(){
     
        // hide #back-top first
        $(".go-top").hide();
         
        // fade in #back-top
        $(function () {
            $(window).scroll(function () {
                if ($(this).scrollTop() > 250) {
                    $('.go-top').fadeIn();
                } else {
                    $('.go-top').fadeOut();
                }
         });
     
        // scroll body to 0px on click
		$('.go-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
        });    
    	});
    </script>

	
	<!-- NiceScroll -->
    <script>
    $(document).ready(function(){
		$("html").niceScroll({
        preservenativescrolling: false,
        cursorwidth: '10px',
        cursorborder: 'none',
        cursorborderradius:'0px',
        cursorcolor:"#3F4D58",
        background:"#999999"
        });
    });
    </script> 
    
    
  </body>
</html>