<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>موسسه کاریابی نیاز رشت</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/main-css.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css"> 
    <link href="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-8/16/Addons-icon.png" rel="shortcut icon">
    
  </head>
  
  <body>
  
  <!--Search -->
  <div id="search-modal" class="modal fadeInLeftBig">
  <div class="modal-dialog" style="margin: 0; left: 100px; top: 24px">
  	<div class="modal-content" style="width: 250px;background: none;border: 0;box-shadow: none">
  		<div class="searchbar">
  		<div class="modal-body" style="direction: ltr;padding: 3px">
  			<div class="input-group">
				<div class="input-group-btn">
					<button class="btn" id="btn-submit" type="submit"><i class="fa fa-search"></i></button>
				</div>
				<input class="form-control" id="txt-search" type="text" style="direction: rtl"  placeholder="متن خود را وارد نمایید...">
			</div>
		</div>
  		</div>
  	</div>
  </div>	
  </div>
  
  	<!-- Login form -->
 	 <div id="myModal" class="modal fade"  role="dialog">
     	<div class="modal-dialog" style="max-width: 450px">
        
     		<div class="modal-content">
            
                <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 style="color: #F04903">ورود به سایت</h4>
                </div>
                
                <div class="modal-body">
                    <form action="login.php" method="post" role="form">
                        <div class="form-group">
                            <label for="usrname">نام کاربری</label>
                            <input type="text" class="form-control" id="usrname" placeholder="نام کاربری را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="psw">کلمه عبور</label>
                            <input type="text" class="form-control" id="psw" placeholder="کلمه عبور را وارد نمایید">
                        </div>
                        <div class="checkbox">
                            <input type="checkbox" value="" checked><label>مرا به خاطر بسپار</label>
                        </div>
                        <button type="submit" class="btn btn-success btn-block">ورود</button>
                    </form>
                </div>
        
                <div class="modal-footer">
                    <p><a href="#">فراموشی کلمه عبور؟</a></p>
                    <p> آیا عضو نیستید؟ <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#RegModal" data-dismiss="modal">ثبت نام</button>
                    <button type="submit" class="btn btn-danger" data-dismiss="modal">انصراف</button></p>
                </div>
                
      		</div>
            
		</div>
	</div>
   
   <!-- Register form -->
   <div id="RegModal" class="modal fade"  role="dialog">
     	<div class="modal-dialog" style="max-width: 400px">
        
     		<div class="modal-content">
            
                <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 style="color: #F04903">ثبت نام در سایت</h4>
                </div>
                
                <div class="modal-body">
                    <form action="register.php" method="post" role="form">
                        <div class="form-group">
                            <label for="name">نام</label>
                            <input type="text" class="form-control" id="mo-fname" placeholder="نام خود را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="family">نام خانوادگی</label>
                            <input type="text" class="form-control" id="mo-lname" placeholder="نام خانوادگی را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="username">نام کاربری</label>
                            <input type="text" class="form-control" id="mo-uname" placeholder="نام کاربری را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="email">پست الکترونیکی</label>
                            <input type="text" class="form-control" id="mo-email" placeholder="پست الکترونیکی را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="psw">کلمه عبور</label>
                            <input type="text" class="form-control" id="mo-psw" placeholder="کلمه عبور را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="re-psw">تایید کلمه عبور</label>
                            <input type="text" class="form-control" id="mo-repsw" placeholder="کلمه عبور را دوباره وارد نمایید">
                        </div>
                        <div class="form-group">
                            <label for="captcha">کد امنیتی</label>
                            
                        </div>
                    </form>
                </div>
        
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-dismiss="modal">ثبت نام</button>
                    <button type="button" class="btn btn-success" data-dismiss="modal" data-toggle="modal" data-target="#myModal">ورود</button>
                </div>
                
      		</div>
            
		</div>
	</div>
    
    <!--header-->
    <header id="header">
    	<div class="container-fluid text-center">
            <div class="logo">
                <a href="index.php"><h2 class="logo-txt wow fadeInRight">نیاز رشت</h2></a>
                <a href="index.php"><h6 class="logo-txt wow fadeInRight">تبلیغات/استخدام و کاریابی</h6></a>
            </div>
            <div class="login text-center">
            	<a href="#"><i class="login-tx fa fa-user-o fa-2x wow fadeIn" data-toggle="modal" data-target="#myModal"></i></a>
                <a href="#"><i class="search-tx fa fa-search fa-2x wow fadeIn" data-toggle="modal" data-target="#search-modal"></i></a>
            </div>
        </div>
        	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-toggles">
            	<span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
    </header>
    
    <!--navbar-->
    <nav id="navbar">
    
    	<div class="container-fluid text-center">
        	
            <div class="nav-toggles navbar-collapse collapse">
        	<ul class="nav nav-pills">
            	<li style="margin-top:5px;padding-top:2px"><a href="about.php">درباره ما</a></li> 
                <li id="contac-us" style="margin-top:5px;padding-top:2px"><a href="#contact-us">تماس با ما</a></li> 
                <li style="margin-top:5px;padding-top:2px"><a href="#">شرکت ها</a></li>
                <li style="margin-top:5px;padding-top:2px"><a href="#">مشاغل گیلان</a></li>
                <li style="margin-top:5px;padding-top:2px"><a href="#">فرصت شغلی</a></li> 
                <li style="margin-top:5px;padding-top:2px"><a href="#">تبلیغات</a></li>
            	<li><a href="index.php"><i class="fa fa-home fa-2x"></i></a></li>         	
            </ul>
            </div>
        </div>
    </nav>
    
    <!-- slider & job -->
    <section id="sliders">
    
    <!--slider -->
    <div id="slider" class="col-md-5 col-xs-12 text-center wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">
    	<div class="img-responsive">
        	<div id="mycarousel" class="carousel slide" data-interval="3000" data-ride="carousel">
            	<ol class="carousel-indicators">
                	<li data-target="#mycarousel" data-slide-to="0" class="active numbers">1</li>
                    <li data-target="#mycarousel" data-slide-to="1" class="numbers">2</li>
                    <li data-target="#mycarousel" data-slide-to="2" class="numbers">3</li>
                </ol>
                <div class="carousel-inner">
                
                	<div class="active item">
                    	<img src="img/slider1.jpg" style="height:400px" class="img-responsive">
                        
                        	<div class="carousel-caption text-center">
                            	<h4>گیلان شناسی، گیلان را بیشتر بشناسید</h4>
                            </div>
                        
                    </div>
                    
                    <div class="item">
                    	<img src="img/slider2.jpg" style="height:400px" class="img-responsive">
                        
                        	<div class="carousel-caption">
                            	<h4>با مناطق دیدنی گیلان  آشنا شوید</h4>
                            </div>
                        
                    </div>
                    
                    <div class="item">
                    	<img src="img/slider3.jpg" style="height:400px" class="img-responsive">
                        
                        	<div class="carousel-caption">
                            	<h4>پیگیری اخبار انتخاباتی در تمامی شهر های استان گیلان</h4>
                            </div>
                        
                    </div>
                    
                    
                </div>
                    <a class="carousel-control left" href="#mycarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    
                    <a class="carousel-control right" href="#mycarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>
            </div>
        </div>
    </div>
    
    <!-- last job -->
    <div id="last-job1" class="text-center col-md-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
        <div class="panel panel-info">
            <div class="panel-heading">
                <h2 class="panel-title"> اخبار انتخاباتی <i class="ti-ico fa fa-feed"></i></h2>
            </div>
            <div class="panel-body fix-panel">
            	<div class="last-news-link">
                	<div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news1.png" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">رد صلاحیت ۲۶ داوطلب انتخابات شورای شهر رشت</a></span>
                    </div>
                    
					<div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news2.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">ستاد روحانی در لنگرود توسط رییس سازمان برنامه و بودجه گیلان افتتاح شد+ تصاویر</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news3.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">مرگ دو دختر جوان در پی سقوط ۲۰۶ در سفیدرود + عکس</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news4.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">جهانگیری و روحانی علیه قالیباف/ جهانگیری: نماینده اصلاح‌طلبان هستم + عکس</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news5.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">تبلیغات رادیویی و تلویزیونی نامزدها از چهارشنبه آغاز می شود</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news6.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">حضور و فعالیت مدیران دولتی با حفظ سمت در ستادهای انتخاباتی خلاف قانون است</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news7.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">تخلف مسؤولان اجرایی گیلان در حمایت از کاندیدای خاص</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news8.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">کشف ابزار یراق و مواد خوراکی قاچاق در رشت</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news9.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">رگبار باران، وزش باد و احتمال رعد و برق در گیلان طی سه روز آینده</a></span>
                    </div>
                    
                    <div class="row" style="margin-right:-10px;padding:0 0 5px 0">
                	<span class="img-thumble"><a href="#"><img src="img/news-thumb/news10.jpg" class="img-responsive img-circle"></a></span>
            		<span class="img-text"><a href="#">ورزشکار گیلانی به اردوی تیم ملی قایقرانی دعوت شد</a></span>
                    </div>
                    
                    
                </div>

            </div>
        </div>
    </div>
    
    <div id="last-job2" class="text-center col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
        <div class="panel panel-info">
            <div class="panel-heading">
                <h2 class="panel-title"> آخرین استخدامی ها <i class="ti-ico fa fa-calendar"></i></h2>
            </div>
            <div class="panel-body fix-panel">
            	<div class="last-job-link">
                	<div class="row">
                    <li class="job-text"><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام کارشناس تولید محتوا و مترجم در گیلان</a></li>
                    </div>
                    
					<div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام طراح وب سایت Front-end Developer در مشهد</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام برشکار سراجی، چرخکاردر تولیدی کیف در گیلان</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام سردبیر/ویراستار با مزایای مناسب در شرکت پلازا رشت</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام مدرس زبان انگلیسی (خانم) در آموزشگاه زبان دهکده در قم</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام تخصص هایIT،برنامه نویسی و سخت افزار در کرج</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام بانک تجارت سال ۹۶ (مهلت ثبت نام تا ۳ اردیبهشت)</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">اخبار استخدام آموزش و پرورش در سال ۹۶</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام کارشناس فروش در گروه رسانه های پیک برتر در تهران</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">استخدام ۵ ردیف شغلی در یک شرکت معتبر بازرگانی در تهران</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب یک فروشنده خانم آشنا به کامپیوتر و فتوشاپ در فروشگاه دکوراسیون داخلی در خ معلم</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">دعوت به همکاری برنامه نویس موبایل اندروید و iOS </a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب 4 نماینده فروش حضوری خانم و آقا در کانون تبلیغاتی در بلوار انصاری</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب یک فروشنده ساده آقا در صنایع دوزندگی در لاکانی</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب 1 نیروی خانم در مغازه سبزیجات آماده در رشت</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب 2 کارگر خانم در صنایع بسته بندی کارتن در جاده رشت به انزلی</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب حسابدار و مدیر فروش در سنگ فروشی در بلوار دیلمان</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب برنامه نویس php و گرافیست وب دارای نمونه کار در شرکتی در رشت</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب متصدی خدمات اینترنت و تایپیست ماهر در کافی نت در خ سعدی</a></li>
                    </div>
                    
                    <div class="row">
                    <li><i class="fa fa-angle-left"></i>
            		<a href="#">جذب 1 حسابدار خانم مسلط به هلو در شرکتی در رشت</a></li>
                    </div>

                </div>

            </div>
        </div>
    </div>
    
    </section>
    
    <!-- Interview -->
    <section id="interview">
    	<div class="container text-center">
        	<div class="row">
    			<div class="sliderinterview col-md-12">
                
      				<div class="carousel carousel-showmanymoveone slide wow fadeInRight" data-wow-duration="1s" data-wow-delay=".8s" id="carousel123">
        				<div class="carousel-inner">
                        
                          <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                            	<div class="interview-box">
                                	<div class="panel">
                                    	<div class="panel-heading">
                                        	<img src="img/slider11.jpg" class="img-responsive">
                                        </div>
                                        <div class="panel-body">
                                        	<p>متن مصاحبه با جناب دکتر صفری</p>
                                            <p>کاندید شورای شهر رشت</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                          
                          
         				</div>
        <a class="left carousel-control" href="#carousel123" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
        <a class="right carousel-control" href="#carousel123" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
              	
              </div>
              
            </div>
          </div>
        </div>
    </section>
    
    <!-- adv 
    <section id="advs">
		<div class="container text-center">
			<div class="row">
            	<div class="col-md-3 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".8s">
                <div class="img-thumb">
                   <img src="img/adv2.jpg" class="img-responsive" alt="image">
                   <div class="img-overly">
                    	<a href="img/adv2.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
</div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay="1s">
                <div class="img-thumb">
                    <img src="img/adv3.jpg" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/adv3.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.2s">
                <div class="img-thumb">
                    <img src="img/adv4.jpg" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/adv4.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="1.4s">
                <div class="img-thumb">
                	<img src="img/adv5.jpg" class="img-responsive" alt="image">
					<div class="img-overly">
                    	<a href="img/adv5.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
            </div>
        </div>
    </section>
    -->
    
    <!-- Job -->
    <section id="job">
    	<div class="container text-center">
        	<div class="row">
            	<div class="new-job1 col-sm-6 col-md-6 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".5s">
                	<div class="panel panel-primary">
                    	<div class="panel-heading">
                        	<div class="panel-title">فرصت های شغلی روزانه</div>
                        </div>
                        <div class="panel-body">
                        	<div class="last-job-link">
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام کارشناس تولید محتوا و مترجم (دورکاری و پاره وقت)در گیلان</a>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام طراح وب سایت Front-end Developer در مشهد</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام برشکار سراجی، چرخکاردر تولیدی کیف وچمدان در گیلان</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام سردبیر / ویراستار با مزایای مناسب در شرکت پلازا در رشت</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام مدرس زبان انگلیسی (خانم) در آموزشگاه زبان دهکده در قم</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام تخصص هایIT،برنامه نویسی و سخت افزار در کرج</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام بانک تجارت سال ۹۶ (مهلت ثبت نام تا ۳ اردیبهشت)</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">اخبار استخدام آموزش و پرورش در سال ۹۶</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام کارشناس فروش در گروه رسانه های پیک برتر در تهران</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام ۵ ردیف شغلی در یک شرکت معتبر بازرگانی در تهران</a></li>
                                </div>

                			</div>
                            <div class="panel-footer">
                            	<div class="more-job"><a href="#" class="btn btn-info btn-block"><span class="fa fa-angle-down"></span>  مشاهده ادامه لیست</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="new-job2 col-sm-6 col-md-6 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".7s">
                	<div class="panel panel-primary">
                    	<div class="panel-heading">
                        	<div class="panel-title">فرصت های شغلی ویژه</div>
                        </div>
                        <div class="panel-body">
                        	<div class="last-job-link">
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام کارشناس تولید محتوا و مترجم (دورکاری و پاره وقت)در گیلان</a>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام طراح وب سایت Front-end Developer در مشهد</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>03&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام برشکار سراجی، چرخکاردر تولیدی کیف وچمدان در گیلان</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام سردبیر / ویراستار با مزایای مناسب در شرکت پلازا در رشت</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام مدرس زبان انگلیسی (خانم) در آموزشگاه زبان دهکده در قم</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام تخصص هایIT،برنامه نویسی و سخت افزار در کرج</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>02&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام بانک تجارت سال ۹۶ (مهلت ثبت نام تا ۳ اردیبهشت)</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">اخبار استخدام آموزش و پرورش در سال ۹۶</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام کارشناس فروش در گروه رسانه های پیک برتر در تهران</a></li>
                                </div>
                                
                                <div class="row" style="margin-right:5px">
                                <p>01&nbsp;اردیبهشت 1396</p>
                                <a href="#">استخدام ۵ ردیف شغلی در یک شرکت معتبر بازرگانی در تهران</a></li>
                                </div>
                			</div>   
                            <div class="panel-footer">
                            	<div class="more-job"><a href="#" class="btn btn-info btn-block"><span class="fa fa-angle-down"></span>  مشاهده ادامه لیست</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
	
    <!-- Company adv -->
	<section id="co-advs">
    	<div class="section-heading text-center">
        	<h3 class="text-uppercase">مشاغل برتر</h3>
            <hr class="icon">
        </div>
    
    	<div class="container text-center">
        	<div class="row">
            	<div class="col-md-3 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".3s">
                <div class="img-thumb">
                	<img src="img/job5.gif" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job5.gif" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                <div class="img-thumb">
                	<img src="img/job1.png" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job1.png" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay=".7s">
                <div class="img-thumb">
                	<img src="img/job2.jpg" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job2.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay=".9s">
                <div class="img-thumb">
                	<img src="img/job3.png" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job3.png" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <div class="img-thumb">
                	<img src="img/job4.jpg" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job4.jpg" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.2s">
                <div class="img-thumb">
                	<img src="img/job6.gif" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job6.gif" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.4s">
                <div class="img-thumb">
                	<img src="img/job7.gif" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job7.gif" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="1.6s">
                <div class="img-thumb">
                	<img src="img/job8.png" class="img-responsive" alt="image">
                    <div class="img-overly">
                    	<a href="img/job8.png" data-lightbox="lightbox"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                </div>
                
            </div>

        </div>
    </section>

	<!-- state -->
	<section id="state">
    	<div class="section-heading text-center">
        	<h3 class="text-uppercase">نگاه آماری سایت</h3>
            <hr class="icon2">
        </div>
    
    	<div class="container-fluid text-center">
        	<div class="row">
            	<div class="stat col-md-3 col-sm-6 col-xs-12 company-no text-center">
                	<i class="fa fa-building-o"></i>
                    <h2><strong class='numscroller' data-min='1' data-max='96' data-delay='5' data-increment='3'></strong></h2>
                    <h4>تعداد شرکت ها</h4>
                </div>
                
                <div class="stat col-md-3 col-sm-6 col-xs-12 job-no text-center">
                	<i class="fa fa-handshake-o"></i>
                    <h2><strong class='numscroller' data-min='1' data-max='811' data-delay='5' data-increment='5'></strong></h2>
                    <h4>تعداد مشاغل</h4>
                </div>
                
                <div class="stat col-md-3 col-sm-6 col-xs-12 Employer-no text-center">
                	<i class="fa fa-user"></i>
                    <h2><strong class='numscroller' data-min='1' data-max='167' data-delay='5' data-increment='3'></strong></h2>
                    <h4>تعداد کارفرما</h4>
                </div>
                
            	<div class="stat col-md-3 col-sm-6 col-xs-12 Job-seeker-no text-center">
                	<i class="fa fa-users"></i>
                    <h2><strong class='numscroller' data-min='1' data-max='412' data-delay='5' data-increment='4'></strong></h2>
                    <h4>تعداد کارجویان</h4>
                </div>
  
            </div>
        </div>
    </section>

	<!-- Contact us-->
	<section id="contact-us">
    	<div class="section-heading text-center">
        	<h3 class="text-uppercase">تماس با ما</h3>
            <hr class="icon3">
        </div>
        
    	<div class="container-fluid">
        	<div class="row">
                <div class="col-md-6 col-xs-12 text-center google-map wow fadeInRight" data-wow-duration="1s" data-wow-delay=".5s">
                	<div class="about-address text-center">
                    <iframe class="google-maps" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d25397.89790909711!2d49.588937670654296!3d37.27765755864641!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sfa!2sir!4v1493290096732" width="600" height="335" frameborder="0" style="border:0" ></iframe>
                   
                   <div class="about-company text-center">
                    	<div class="row">
                            <div class="col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay=".6s">
								<i class="fa fa-envelope"></i>
                                <h5>پست الکترونیکی :</h5>
                                <h5>Info@niazguilan.ir</h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay=".7s">
                                <i class="fa fa-phone-square"></i>
                                <h5>شماره تماس :</h5>
                                <h5>2323 013</h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay=".8s">
                                <i class="fa fa-map-marker"></i>
                                <h5>آدرس :</h5>
                                <h5>گیلان، رشت</h5>
                            </div>
                        </div>
                   
                    </div>
                    
                        
                    </div>
                </div>
                
                <div class="col-md-6 col-xs-12 text-center contact-form wow fadeInDown" data-wow-duration="1s" data-wow-delay="1s">
                	<form>
                    	<div class="row">
                        	<div class="col-md-6 col-xs-12">
                            	<div class="form-group">
                                	<input type="text" class="form-control" placeholder="نام خانوادگی">
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                            	<div class="form-group">
                                	<input type="text" class="form-control" placeholder="نام">
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                            	<div class="form-group">
                                	<input type="text" class="form-control" placeholder="شماره تلفن">
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                            	<div class="form-group">
                                	<input type="text" class="form-control" placeholder="پست الکترونیکی">
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="متن خود را وارد کنید" style="height:240px"></textarea>
                                </div>
                            </div>
                            <div class="col-xs-12">
                            	<button type="submit" class="btn btn-default">ارسال</button>
                            	<a href="contactus.php"><button type="button" class="btn btn-info" style="margin-right: 5px"><i class="fa fa-refresh"></i>&nbsp;  ارتباط با مدیریت</button></a>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </section>
    
	<!-- footer -->
	<footer id="footer">
    	<div class="container text-center">
        	<div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <a href="index.php"><h2 class="logo-txt">نیاز رشت</h2></a>
                        <a href="index.php"><h6 class="logo-txt">تبلیغات/استخدام و کاریابی</h6></a>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <h4 class="footer-text">در شبکه های اجتماعی دنبال کنید</h4>
                        <div class="footer-img">
                        	<ul>
                            	<li class="facebook"><a href="https://www.facebook.com/niazerasht"><i class="fa fa-facebook-square"></i></a></li>
                                <li class="twitter"><a href="https://twitter.com/niazerasht"><i class="fa fa-twitter-square"></i></a></li>
                                <li class="instagram"><a href="http://instagram.com/niazerasht"><i class="fa fa-instagram"></i></a></li>
                                <li class="linkedin"><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                                <li class="telegram"><a href="http://telegram.me/niazerasht"><i class="fa fa-telegram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logo text-center">
                        <h4 class="footer-text">عضویت در خبرنامه</h4>
                        <div class="input-group">
                            <div class="input-group-btn">
                            	<button class="btn" id="btn-submits" type="submit">ارسال</button>
                            </div>
                            <input class="form-control" id="txt-email" type="text" placeholder="ایمیل خود را وارد کنید...">
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <div class="footer-logos">
                        <h5 class="footer-text">مختصری از نیاز رشت</h5>
                        <p class="mini-about text-justify">
                        	وب سایت نیاز رشت در سال 1396 تاسیس شده است. فعالیت های این وب سایت بیشتر در حوزه کاریابی و تبلیغات بصورت درون شهری، فضای مجازی و ... می باشد. 
                        </p>
                    </div>
                </div>

            </div>
            
        </div>
        <span class="go-top">
            <a href="#top"><i class="fa fa-chevron-circle-up"></i></a>
        </span>
        <span class="text-center">
        <h6 class="footer-copyright"><i class="fa fa-copyright"></i> Copyright 2017 &nbsp; طراحی توسعه و پشتیبانی توسط تیم طراحی و توسعه رش بیت</h6>
        </span>
    </footer>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  	<script src="js/numscroller-1.0.js"></script>
    <script src="js/lightbox-plus-jquery.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    
    <!-- wow animation -->
    <script>
		new WOW().init();
	</script>
    
    <!-- Fixed Top Menu    
    <script> var aboveHeight = $('header').outerHeight(); 
		$(window).scroll(function(){ 
			if ($(window).scrollTop() > aboveHeight){ 
				$('#navbar').css({"position":"fixed","top":"0px","z-index":"1","opacity":"0.9","padding-top":"5px"}); 
			} else { 
				$('#navbar').css({"position":"static","opacity":"1","z-index":"0","padding-top":"0"}); 
		} }); 
    </script>
	-->
    
  	<!-- Go top -->
	<script>
    	$(document).ready(function(){
     
        // hide #back-top first
        $(".go-top").hide();
         
        // fade in #back-top
        $(function () {
            $(window).scroll(function () {
                if ($(this).scrollTop() > 250) {
                    $('.go-top').fadeIn();
                } else {
                    $('.go-top').fadeOut();
                }
         });
     
        // scroll body to 0px on click
		$('.go-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
        });    
    	});
    </script>
	
    <!-- Go Contact-us -->
	<script>
		$('#contac-us').click(function() {
    	$('html, body').animate({
      	scrollTop: $('#contact-us').offset().top
    	}, 2000)
  		});
	</script>
	
	<!-- NiceScroll -->
    <script>
    $(document).ready(function(){
		$("html").niceScroll({
        preservenativescrolling: false,
        cursorwidth: '10px',
        cursorborder: 'none',
        cursorborderradius:'0px',
        cursorcolor:"#3F4D58",
        background:"#999999"
        });
    });
    </script> 
    
    <script>
	$(document).ready(function(){
		
        $(".fix-panel").niceScroll({
			preservenativescrolling: false,
			cursortop:'0px',
			cursorright:'0px',
			cursorborder:'none',
			cursorborderradius:'1px',
			cursorclear:'both',
			cursorvisibility:'hidden',
			cursorzindex:'-99999',
			cursorposition:'fixed',
			cursorfixed: true,
			});
    });
	
	</script>
   
    <!-- hide scroll in start 
	<script>
	$(window).scroll(function(){
 
 
    var $heightScrolled = $(window).scrollTop();
   
    if($heightScrolled > 0){
        parent.scroll(1,0)
        };
        });
	</script>
    -->
    
    <!-- Interview SLider -->
    <script>
		(function(){
		  // setup your carousels as you normally would using JS
		  // or via data attributes according to the documentation
		  // http://getbootstrap.com/javascript/#carousel
		  $('#carousel123').carousel({ interval: 2000 });
		  $('#carouselABC').carousel({ interval: 3600 });
		}());
    </script>
	<script>
		(function(){
		  $('.carousel-showmanymoveone .item').each(function(){
			var itemToClone = $(this);
		
			for (var i=1;i<4;i++) {
			  itemToClone = itemToClone.next();
		
			  // wrap around if at end of item collection
			  if (!itemToClone.length) {
				itemToClone = $(this).siblings(':first');
			  }
		
			  // grab item, clone, add marker class, add to collection
			  itemToClone.children(':first-child').clone()
				.addClass("cloneditem-"+(i))
				.appendTo($(this));
			}
		  });
		}());
    </script>
    
  </body>
</html>